<div class="container-fluid">
    <nav class="navbar navbar-expand-sm navbar-light bg-info mt-2">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Rattrapage</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarID"
                aria-controls="navbarID" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarID">
                <div class="navbar-nav">

                    <a class="nav-link active" aria-current="page" href="<?=BASE_URL?>/patient/new/form">Ajouter patient</a>
                    <a class="nav-link active" aria-current="page" href="<?=BASE_URL?>/patient/liste">liste des patients</a>
                    <a class="nav-link active" aria-current="page" href="<?=BASE_URL?>/rendez-vous/new/form">Ajouter rendez-vous</a>
                    <a class="nav-link active" aria-current="page" href="<?=BASE_URL?>/rendez-vous/liste">liste des rendez-vous</a>

                </div>
            </div>
    </nav>

</div>