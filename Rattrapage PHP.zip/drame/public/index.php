
<?php

    use App\Controllers\PatientController;
    use App\Core\Router;
    use App\Models\Prestation;

    require_once "./../vendor/autoload.php";
    require_once "./../src/core/Boostrap.php";
    
    Router::route("/",[PatientController::class,"liste"]);
    Router::route("/patient/new/form",[PatientController::class,"showAddForm"]);

    Router::resolve();
