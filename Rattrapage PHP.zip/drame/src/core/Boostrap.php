<?php

    define("TYPEPRESTATION",["Analyse","Radio"]);
    define("ETATRENDEZVOUS",["Encours","Annuler"]);
    define("BASE_URL","http://localhost:8000");


